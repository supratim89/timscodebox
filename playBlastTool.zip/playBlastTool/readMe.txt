After unzipping playBlastTool.rar keep the entire folder in Desktop.
Drag and drop playBlastTool.py into Maya script editor and RUN!
Thanks. :)